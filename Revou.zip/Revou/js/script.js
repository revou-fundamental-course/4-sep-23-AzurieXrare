document.addEventListener("DOMContentLoaded", function () {
    const squareForm = document.getElementById("square-form");
    const sideLengthInput = document.getElementById("sideLength");
    const calculateButton = document.getElementById("calculate-button");
    const resultDiv = document.getElementById("result");
    const luasResult = document.getElementById("luasResult");
    const kelilingResult = document.getElementById("kelilingResult");

    squareForm.addEventListener("submit", function (e) {
        e.preventDefault();

        // Get the input value
        const sideLength = parseFloat(sideLengthInput.value);

        // Check if the input is a valid number
        if (isNaN(sideLength)) {
            alert("Invalid input. Please enter a valid number.");
            return;
        }

        // Calculate luas and keliling
        const luas = sideLength * sideLength;
        const keliling = 4 * sideLength;

        // Display the results
        luasResult.textContent = luas.toFixed(2);
        kelilingResult.textContent = keliling.toFixed(2);
        resultDiv.classList.remove("hidden");
    });
});
